/**
 * This is the openload file api
 * 
 * 1. getAccountInfo(id, key); vaild the user input api info
 * 2. upload(link_address, headers);  `headers` may include `cookies` `referer` and so on;
 * 3. listFloder(current_floder)
 * 4. uploadLocalFile(); 
 */



function isConfigLogin(){
	var uid = localStorage.login;
	var key = localStorage.token;

	if (!isVaild(uid))
	{
		window.location="/options.html"
		return false;
	}
	if (!isVaild(key))
	{
		window.location="/options.html"
		return false;;
	}
	return true;
}

function getAccountInfo(id, key){
  var svr = "https://api.openload.co/1/account/info?login={login}&key={key}"
  if (!isConfigLogin())
  {
	return false;
  }
  var url = svr.format({login: localStorage.login, key: localStorage.token});
  var xhr = new XMLHttpRequest();
  xhr.open("GET", url);
  xhr.onload = function () {
	if (this.status == 200) {
      var result = JSON.parse(this.responseText);
	  var info = $("#user_info")[0];
 	  info.children[0].textContent= result.result.email;
	  info.children[1].textContent= result.result.extid;
	}else {
	  notification.notify("Failed" + this.status);
	}
  };
  xhr.send();
}

function upload(){
    var svr = "https://api.openload.co/1/remotedl/add?login={login}&key={key}&url={url}";

	if (!isConfigLogin())
	{
		return false;
	}

	var addr =  document.getElementById("url");
	var folder = document.getElementById("select_folder_list");
	var headers =  document.getElementById("headers");

	if (!isVaild(addr))
	{
		notification.notify("url empty!");
		return;
	}else if (!IsURL(addr.value.toLowerCase()))
	{
		notification.notify("url addr invalid!");
		return;
	}
	var url = svr.format({login: localStorage.login, key: localStorage.token, url: addr.value});
	if (isVaild(folder))
	{
		url = url + "&folder={folder}".format({folder:folder.value})
	}
	if (isVaild(headers))
	{
		url = url + "&headers={headers}".format({headers:headers.value})
	}
	console.log(url);
	var xhr = new XMLHttpRequest();
    xhr.open("GET", url);

    xhr.onload = function () {
      if (this.status == 200) {
        notification.notify(this.responseText);
      }else {
        notification.notify("faild" + this.status);
      }
    };
	xhr.send();
}


function getFloder(){
    var svr = "https://api.openload.co/1/file/listfolder?login={login}&key={key}"
	if (!isConfigLogin())
	{
		return false;
	}
	var url = svr.format({login: localStorage.login, key: localStorage.token});
	var sub_folder = arguments[1];
	if (isVaild(sub_folder))
	{
		url = url + "&folder={folder}".format({folder: sub_folder});
	}
	console.log(url);
	var xhr = new XMLHttpRequest();
    xhr.open("GET", url);
	var sels = document.getElementById("select_folder_list");
    xhr.onload = function () {
      if (this.status == 200) {
        var result = JSON.parse(this.responseText);
		var i, floders = result.result.folders;
		for (i=0; i<floders.length; i++)
		{	
			console.log(floders[i]);
			sels.options.add(new Option(floders[i].name, floders[i].id));
		}
      }else {
        notification.notify("faild" + this.status);
      }
    };
	xhr.send();
}
