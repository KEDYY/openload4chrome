

document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('extension_version').textContent = version;
  var reverse_list_input = document.getElementById('reverse_list');
  var hide_data_input = document.getElementById('hide_data');
  var chrome_sync_input = document.getElementById('sync');
  var uid = document.getElementById('user_id');
  var token = document.getElementById('user_token');


  var save_button = document.getElementById('save');

  chrome.storage.sync.get(["login", "token", "reverse_list", "hide_data", "sync"], function(items) {
    reverse_list_input.checked = items.reverse_list;
	hide_data_input.checked = items.hide_data;
    uid.value = getElseEmpty(items.login);
    token.value = getElseEmpty(items.token);
	localStorage.login = uid.value;
	localStorage.token = token.value;
  });

  save_button.addEventListener('click', function() {
	if(!$("form")[0].checkValidity()){
		notification.notify("Please Enter Login ID and Key");
		return;
	}

    var new_options = {
      reverse_list: reverse_list_input.checked,
      hide_data: hide_data_input.checked,
      chrome_sync: chrome_sync_input.checked,
	  login: uid.value,
      token: token.value
    };

    chrome.storage.sync.set(new_options, function() {
      notification.notify('Options saving...');
      setTimeout(function() {
        notification.notify('save Timeout');
      }, 5000);
      chrome.runtime.sendMessage({ action: 'update-options', options: new_options });
    });
	localStorage.login = uid.value;
	localStorage.token = token.value;
	chrome.storage.sync.get(["login", "token"], function(item){
		console.log(item.login);
		console.log(item.token);
	});
  });

  document.getElementById('reset').addEventListener('click', function() {
    reverse_list_input.checked = false;
    hide_data_input.checked = false;
    chrome.storage.sync.clear(function() {
      notification.notify('Options reset...');
      setTimeout(function() {
        notification.notify('reset Timeout');
      }, 5000);
      chrome.runtime.sendMessage({ action: 'update-options', options: default_options });
    });
  });
});
